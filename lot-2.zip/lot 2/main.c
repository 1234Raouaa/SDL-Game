#include<stdio.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include<SDL/SDL_mixer.h>
#include "image.h"
#include "text.h"
//#include"text.h"

void main()
{
TTF_Init();
SDL_Init(SDL_INIT_VIDEO); //Initialisation de la SDL
SDL_Surface *screen;
Background Backg;
int n=0,x=0,musica=0,i, play=1, direction=-1, pas =5;

 SDL_Event event;
screen=SDL_SetVideoMode(500,260, 32, SDL_HWSURFACE|SDL_DOUBLEBUF); 
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);
initBack(&Backg);
while (play==1)
{
if (Backg.numusique==0)
{Mix_PlayMusic(Backg.musique[0],-1);
Backg.numusique=2;}
if(Backg.numusique==1)
{Mix_PlayMusic(Backg.musique[1],-1);
Backg.numusique=2;
}

aficherBack(Backg,screen);
SDL_Delay(100);

//displayText(t,screen,a);
SDL_Flip(screen);
SDL_PollEvent(&event);
switch(event.type)
        {
            case SDL_QUIT:
                screen = 0;
            break;
case SDL_KEYDOWN:
    		 	switch(event.key.keysym.sym){
case SDLK_RIGHT:
direction=0; 
                                
 break;


 case SDLK_LEFT:
                                 direction =1;
break;
                               case SDLK_UP:
direction =2;
 break;
                                
                               case SDLK_DOWN:
direction=3;
break;

}
scrolling(&Backg,direction,pas); 
break;
//scrolling(&Backg,direction,pas); 
}
animerBack (&Backg);
}
}
