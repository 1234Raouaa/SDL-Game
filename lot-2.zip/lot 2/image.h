#ifndef image_H
#define image_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
typedef struct
{
    SDL_Surface* bg[2]; //"pour charger l'image de la bg"
    SDL_Rect posbg;//"position du bg"
    SDL_Rect poscam;//"pos du camera scrolling"
    SDL_Surface* vie[4];
    SDL_Rect poscoeur;
    Mix_Music *musique[2];
    Mix_Chunk *son;
    int numbg,numvie,numusique;


}Background;
void initBack(Background * b);
void aficherBack(Background b, SDL_Surface * screen);
void scrolling (Background * b, int direction, int pas ); 
//void scrolling (SDL_Rect * b, int direction );
void animerBack (Background* b);
/*void saveScore(ScoreInfo  s,  char *fileName); 
void bestScore(char * filename,  ScoreInfo  t[]); */
#endif

