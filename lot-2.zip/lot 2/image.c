#include "image.h"
#include "text.h"
void initBack(Background * Backg) //initialisatation de tt les bgs 
{
Backg->bg[0]=IMG_Load("b.png");
if(Backg->bg[0]==NULL){
printf("unable to load ");
return ;}
Backg->bg[1]=IMG_Load("b2.png");
if(Backg->bg[1]==NULL){
printf("unable to load ");
return ;}
Backg->posbg.x=0;
Backg->posbg.y=-10;
Backg->poscam.x=0;
Backg->poscam.y=-5;
Backg->poscam.w=500;
Backg->poscam.h=260;
Backg->vie[0]=IMG_Load("galbkamel.png");
if(Backg->vie[0]==NULL){
printf("unable to load ");
return ;}
Backg->vie[1]=IMG_Load("galb70.png");
if(Backg->vie[1]==NULL){
printf("unable to load ");
return ;}
Backg->vie[2]=IMG_Load("galb30.png");
if(Backg->vie[2]==NULL){
printf("unable to load ");
return ;}
Backg->vie[3]=IMG_Load("galb0.png");
if(Backg->vie[3]==NULL){
printf("unable to load ");
return ;}
Backg->poscoeur.x=0;
Backg->poscoeur.y=0;
Backg->musique[0]=Mix_LoadMUS("music.mp3");
Backg->musique[1]=Mix_LoadMUS("suspense.mp3");
Backg->son=Mix_LoadWAV("sout.wav");
Backg->numbg=0;
Backg->numvie=0;
Backg->numusique=0;
}
void aficherBack(Background b, SDL_Surface * screen) //afficher le bg et le nb de vie 
{

SDL_BlitSurface(b.bg[b.numbg],&b.poscam,screen,&b.posbg); //la premiere scrolling 
SDL_BlitSurface(b.vie[b.numvie],NULL,screen,&b.posbg);//el thenya al screen directement 
}
void scrolling (Background * b, int direction, int pas ) 
{
if(direction==0)//à droite 
{
b->poscam.x+=pas;
if(b->poscam.x>785)// pour détecter et ne pas sortir de la la limite du bg 
b->poscam.x=785;}
if(direction==1)
{
b->poscam.x-=pas;
if(b->poscam.x<0)
b->poscam.x=0;} 
if(direction==2)//à gauche
{
b->poscam.y-=pas;
if(b->poscam.y<0)
b->poscam.y=0;}
if(direction==3)
{
b->poscam.y+=pas;
if(b->poscam.y>220)
b->poscam.y=220;}
}

void animerBack (Background* b) 
{
if(b->poscam.x==100)
{b->numbg=1;
b->numvie=1;
Mix_PlayChannel(1,b->son,0);
}
else if(b->poscam.x==250)
{b->numbg=1;
b->numvie=2;
b->numusique=1;
Mix_PlayChannel(1,b->son,0);
}
else if(b->poscam.x==400)
{b->numbg=1;
b->numvie=3;
Mix_PlayChannel(1,b->son,0);
}
else
b->numbg=0;
}
/*void saveScore(ScoreInfo  s,  char *fileName)
{

}
void bestScore(char * filename,  ScoreInfo  t[]) 
{

}*/
