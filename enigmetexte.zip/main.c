#include <stdio.h>
#include <stdlib.h>
#include "Enigme.h"

int main()
{

    SDL_Surface *background;
    TTF_Font *police;


    SDL_Surface*screen=NULL;
    SDL_Surface *win, *loss ;
		
    win=IMG_Load("youwin.jpg");
    loss=IMG_Load("youlost.jpg");
		

    SDL_Event event;
    enigme e;
    GenererEnigme(&e);

    TTF_Init();
    int keep=1 ;


    SDL_WM_SetCaption("Release yourself quickly!",NULL);
    if(SDL_Init(SDL_INIT_VIDEO)!=0)
    {
        printf("unable to initilize SDL:%s\n",SDL_GetError());
        return 1;
    }


    screen=SDL_SetVideoMode(1000,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
    if(screen==NULL)
    {
        printf("unable to set video mode: %s\n",SDL_GetError());
    }

    initialiser_enigme(&e);

    while (keep)

    {


        while(SDL_PollEvent(&event))
        {
            switch(event.type)
            {
            case SDL_QUIT:
                keep=0;
                break;
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym)
                {
                case SDLK_ESCAPE :
                    keep = 0;
                    break;
//button a
                case SDLK_a :
                    if (e.right_answer==0)
                    {
                        SDL_BlitSurface(win,NULL,screen,NULL);
                        SDL_Flip(screen);
                        SDL_Delay(3000);
                        keep=0;
                        printf("vrai");
                    }
                    else
                    {
                        SDL_BlitSurface(loss,NULL,screen,NULL);
                        SDL_Flip(screen);
                        SDL_Delay(3000);
                        keep=0;
                        printf("faux");
                    }
//button z
                    break;
                case SDLK_z :
                    if (e.right_answer==1)
                    {
                        SDL_BlitSurface(win,NULL,screen,NULL);
                        SDL_Flip(screen);
                        SDL_Delay(3000);
                        keep=0;
                        printf("vrai");
                    }
                    else
                    {
                        SDL_BlitSurface(loss,NULL,screen,NULL);
                        SDL_Flip(screen);
                        SDL_Delay(3000);
                        keep=0;
                        printf("faux");
                    }
                    break;
//button e
                case SDLK_e:
                    if (e.right_answer==2)
                    {
                        SDL_BlitSurface(win,NULL,screen,NULL);
                        SDL_Flip(screen);
                        SDL_Delay(3000);
                        keep=0;
                        printf("vrai");
                    }
                    else
                    {
                        SDL_BlitSurface(loss,NULL,screen,NULL);
                        SDL_Flip(screen);
                        SDL_Delay(3000);
                        keep=0;
                        printf("faux");
                    }
                    break;
                }
                break;
            }
            animerEnigme(&e);
            AfficherEnigme(&e,screen);

        }
        SDL_Flip(screen);

    }




    SDL_FreeSurface(screen);
    TTF_CloseFont(police);
    SDL_FreeSurface(background);
    TTF_Quit();
    SDL_Quit();

    return 0;
}

