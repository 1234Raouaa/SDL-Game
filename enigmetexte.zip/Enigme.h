#ifndef ENIGME_H_INCLUDED
#define ENIGME_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <time.h>


void init_menu(saving *s)
{
int i;
	s->pos_save.x=0;
	s->pos_save.y=0;
	s->pos_quit.x=0;
	s->pos_quit.y=0;
	s->pos_pause.x=0;
	s->pos_pause.y=0;

	s->pause=NULL;
	s->sure=NULL;
	s->quit=NULL;
	s->quit1=NULL;
	s->save=NULL;
	s->save1=NULL;
	s->quit_and_save=NULL;
	s->quit_no_save=NULL;
	s->quit_sous_menu=NULL;

	for (i=0; i<3; i++)
	{
		s->position[i].x=0;
		s->position[i].y=0;
	}

	s->pause=IMG_Load("save/pause.png");
	s->sure=IMG_Load("save/sure.png");
	s->quit1=IMG_Load("save/quit1.png");
	s->quit=IMG_Load("save/quit.png");

	s->save=IMG_Load("save/save.png");
	s->save1=IMG_Load("save/save1.png");
	s->quit_and_save=IMG_Load("save/quit_and_save.png");
	s->quit_no_save=IMG_Load("save/quit_no_save.png");
	s->quit_sous_menu=IMG_Load("save/quit_sous_menu.png");
}

typedef struct
{
SDL_Surface *background;
SDL_Surface *images[37];

SDL_Rect posbackground;
SDL_Surface *text_e;
SDL_Rect postext_e;
SDL_Surface *text_question;
SDL_Rect postext_question;
SDL_Surface *text_r1;
SDL_Rect postext_r1;
SDL_Surface *text_r2;
SDL_Rect postext_r2;
SDL_Surface *text_r3;
SDL_Rect postext_r3;
TTF_Font *police_e;
int current_frame;



    char question[60];
    char answer1[50],answer2[50], answer3[50]; 
    int right_answer;
   
}enigme;


void initialiser_enigme(enigme *e);
void AfficherEnigme(enigme * e,SDL_Surface * screen);
void GenererEnigme(enigme * e) ;
void animerEnigme(enigme * e) ;


#endif 
