#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "header.h"

int main()
{
    SDL_Init(SDL_INIT_VIDEO);

    SDL_Surface* screen = SDL_SetVideoMode(SCREEN_W, SCREEN_H, 32, SDL_HWSURFACE | SDL_RESIZABLE);
    SDL_Event event;
    if(!screen){
    	printf("erreur %s\n",SDL_GetError());
        return 1;
    	}
    Image Backg;
    initBackground(&Backg);
    Ennemi e;
    initEnnemi(&e);

    int continuer = 1;
    while (continuer) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                continuer = 0;
            }
        }

        move(&e);
        animerEnnemi(&e);
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
	afficher(Backg,screen);
	int nbr_vie=3;
	int score=0;
        Personne p;
        if (collisionBB(p,e)==1){
		nbr_vie--;
		score--;
	}
	if ((nbr_vie==0) || (score<0))
		continuer=0;
	
        afficherEnnemi(e, screen);

        // update the screen
        SDL_Flip(screen);
        SDL_Delay(120);
    }

    SDL_Quit();
    return 0;
}
