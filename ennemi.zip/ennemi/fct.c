#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "header.h"

void initEnnemi(Ennemi *e){
	e->sprite = IMG_Load("/home/vboxuser/Documents/ennemi/police.png");
    	e->direction = 3;
    	e->posscreen.x = 5;
    	e->posscreen.y = 150;
    	e->posscreen.w =  576/ 9;
    	e->posscreen.h = 252 /4 ;
    	e->possprite.x = 0;
    	e->possprite.y = 0;
    	e->possprite.w = 576 / 9;
    	e->possprite.h = 252 / 4;
}

void afficherEnnemi(Ennemi e, SDL_Surface * screen){

	SDL_BlitSurface(e.sprite, &e.possprite, screen, &e.posscreen);
}

void move(Ennemi *e) {
    int posmax = 300;
    int posmin = 0;
	if (e->posscreen.x < posmin){
		e->direction = 3;
	}
	if (e->posscreen.x > posmax){ 
		e->direction = 1;
	}
	if (e->direction == 1){
		e->posscreen.x -= 5;
	}
	else if (e->direction == 3){
		e->posscreen.x += 5;
	}
}

void animerEnnemi(Ennemi *e){
	e->possprite.y = e->direction * (576/9);
	if (e->possprite.x >= 576-(576/9)){
		e->possprite.x = 0;
	}
	e->possprite.x = e->possprite.x + (576/9);
	
}

int collisionBB( Personne p, Ennemi e){
	int collision;
	if (( (p.possprite.x + p.possprite.w) < e.possprite.x) || (p.possprite.x > (e.possprite.x+ e.possprite.w) ) || ( (p.possprite.y + p.possprite.h) < e.possprite. y) || (p.possprite.y >  (e.possprite. y + e.possprite. h)))


            collision = 0 ;  

	else

            collision = 1 ;

	return collision ;
}

void initBackground(Image *Backg)
{
	Backg->img= IMG_Load("/home/vboxuser/Documents/ennemi/backg.jpg");
	if (Backg->img == NULL) {
		printf("Unable to load bitmap: %s\n", SDL_GetError());
		return;
	}
        Backg->pos1.x=0;
	Backg->pos1.y=0;
	Backg->pos2.x=0;
	Backg->pos2.y=0;
	Backg->pos2.w=SCREEN_W;
	Backg->pos2.h=SCREEN_H;
}

void afficher(Image p,SDL_Surface *screen)
{
	SDL_BlitSurface(p.img,&p.pos2,screen,&p.pos1);
}
