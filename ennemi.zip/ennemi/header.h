#ifndef header_H
#define header_H
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#define SCREEN_W 1920
#define SCREEN_H 1080
typedef struct{
	SDL_Rect pos1,pos2;
	SDL_Surface *img;
}Image;

typedef struct {
	SDL_Surface *sprite;
	SDL_Rect possprite;
	SDL_Rect posscreen;
	int direction;
}Ennemi;

// structure de personne
typedef struct {
	SDL_Surface *sprite_sheet;
	SDL_Rect possprite;
	SDL_Rect posscreen;
	int direction;
}Personne ;

void initEnnemi(Ennemi * e);
void afficherEnnemi(Ennemi e, SDL_Surface * screen);
void move( Ennemi * e);
void animerEnnemi( Ennemi * e);
int collisionBB( Personne p, Ennemi e);
void initBackground(Image *Backg);
void afficher(Image p,SDL_Surface *screen);
#endif
